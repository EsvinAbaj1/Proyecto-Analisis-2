package com.example.demo1erurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo1EurekaServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
